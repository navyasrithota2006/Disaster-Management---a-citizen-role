from db_config import get_db_connection
from datetime import datetime
from functools import wraps
from flask import Flask, send_from_directory, render_template, request, redirect, session, url_for, jsonify
import os

app = Flask(__name__, static_url_path='/static')
app.secret_key = 'supersecretkey'  # ⚠️ Change this in production

# Dummy admin credentials
ADMIN_USERNAME = 'navya'
ADMIN_PASSWORD = 'navya2006'


# ------------------- Static Pages -------------------

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/help')
def help_page():
    return render_template('help.html')

@app.route('/help_<type>')
def help_type(type):
    return render_template(f'help_{type}.html')




# ----------------------- Login Required Decorator -----------------------

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('admin_logged_in'):
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return decorated_function


# ------------------ voluntter/contributor ------------------

@app.route('/volunteer-hub')
@login_required
def volunteer_hub():
    return render_template('vc.html')
 # Your full HTML above should be saved as volunteer.html

# ------------------ LOGIN ROUTE ------------------

@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        # ✅ Hardcoded check for super admin
        if email == 'admin@gmail.com' and password == 'admin123':
            session['admin_logged_in'] = True
            return redirect(url_for('dashboard'))

        # ✅ Else check DB for other users
        conn = get_db_connection()
        cur = conn.cursor(dictionary=True)
        cur.execute("SELECT * FROM admin_users WHERE email = %s AND password = %s", (email, password))
        user = cur.fetchone()
        cur.close()
        conn.close()

        if user:
            session['logged_in'] = True
            return redirect(url_for('volunteer_hub'))  # normal user
        else:
            return "⚠️ Invalid credentials"

    return render_template('admin_login.html')





@app.route('/thank_you_volunteer')
@login_required
def thank_you_volunteer():
    return render_template('thank_you_volunteer.html')

@app.route('/thank_you_contributor')
@login_required
def thank_you_contributor():
    return render_template('thank_you_contributor.html')

@app.route('/thank_you_both')
@login_required
def thank_you_both():
    return render_template('thank_you_both.html')












@app.route('/api/volunteers', methods=['GET', 'POST'])
@login_required
def volunteers_api():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == 'POST':
        data = request.get_json()
        name = data.get('name')
        email = data.get('email')
        role = data.get('role')
        opinion = data.get('opinion')

        try:
            # Insert into DB
            cursor.execute("""
                INSERT INTO volunteers (name, email, role, opinion)
                VALUES (%s, %s, %s, %s)
            """, (name, email, role, opinion))
            conn.commit()

            # ✅ New: redirect logic based on role
            redirect_path = f"/thank_you_{role}"
            return jsonify({'success': True, 'redirect': redirect_path}), 201

        except Exception as e:
            print("Database error:", e)
            return jsonify({'error': 'Database error'}), 500

        finally:
            cursor.close()
            conn.close()

    else:  # GET
        cursor.execute("SELECT * FROM volunteers ORDER BY date DESC")
        rows = cursor.fetchall()
        cursor.close()
        conn.close()
        return jsonify(rows)

# ------------------- Admin Login Routes -------------------

@app.route('/signup', methods=['POST'])
def signup():
    fullname = request.form['fullname']
    email = request.form['email']
    password = request.form['password']

    try:
        conn = get_db_connection()
        cur = conn.cursor()

        # Check if email exists
        cur.execute("SELECT * FROM admin_users WHERE email = %s", (email,))
        if cur.fetchone():
            return "⚠️ Email already registered!"

        # Insert into DB
        cur.execute("""
            INSERT INTO admin_users (fullname, email, password)
            VALUES (%s, %s, %s)
        """, (fullname, email, password))

        conn.commit()
        cur.close()
        conn.close()

        return redirect('/admin_login')  # ✅ redirect to login after signup

    except Exception as e:
        return f"Error: {e}"



@app.route('/signup', methods=['GET'])
def signup_page():
    return render_template('signup.html')



@app.route('/weather')
def weather():
    return render_template('weather.html')


@app.route('/contact')
def contact_page():
    return render_template('contact.html')

@app.route('/dashboard')
@login_required
def dashboard():
    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    cur.execute("SELECT * FROM help_requests ORDER BY id DESC")
    food = cur.fetchall()

    # Fetch medical requests
    cur.execute("SELECT * FROM medical_requests ORDER BY id DESC")
    medical = cur.fetchall()

    # Fetch shelter requests
    cur.execute("SELECT * FROM shelter_requests ORDER BY id DESC")
    shelter = cur.fetchall()

    # Fetch fund requests
    cur.execute("SELECT * FROM funds_requests ORDER BY id DESC")
    funds = cur.fetchall()

    # Fetch army requests
    cur.execute("SELECT * FROM army_requests ORDER BY id DESC")
    army = cur.fetchall()

    # Fetch volunteers and contributors
    cur.execute("SELECT * FROM volunteers ORDER BY id DESC")
    volunteers = cur.fetchall()

    cur.close()
    conn.close()

    return render_template('dashboard.html',food=food, medical=medical, shelter=shelter, funds=funds, army=army, volunteers=volunteers)


# ------------------- Service Worker Route -------------------

@app.route('/static/sw.js')
def service_worker():
    return send_from_directory('static', 'sw.js', mimetype='application/javascript')


# ------------------databse route --------------------------------

@app.route('/submit_help', methods=['POST'])
def submit_help():
    lat = request.form.get('latitude')
    lon = request.form.get('longitude')
    disaster_type = request.form.get('disaster_type')
    timestamp = datetime.now()

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO help_requests (disaster_type, latitude, longitude, timestamp)
        VALUES (%s, %s, %s, %s)
    """, (disaster_type, lat, lon, timestamp))

    conn.commit()
    cursor.close()
    conn.close()

    return render_template("thank_you.html", type=disaster_type)


@app.route('/submit_help_medical', methods=['POST'])
def submit_help_medical():
    try:
        latitude = request.form['latitude']
        longitude = request.form['longitude']
        contact = request.form['contact']
        notes = request.form['notes']
        needs = ', '.join(request.form.getlist('needs'))

        db = get_db_connection()
        cursor = db.cursor()

        insert_query = """
            INSERT INTO medical_requests (latitude, longitude, needs, contact, notes)
            VALUES (%s, %s, %s, %s, %s)
        """
        cursor.execute(insert_query, (latitude, longitude, needs, contact, notes))
        db.commit()

        cursor.close()
        db.close()

        return redirect('/help_submitted')  # 👈 Redirect after success

    except Exception as e:
        return f"Error occurred: {str(e)}"





@app.route('/help_submitted')
def help_submitted():
    return '''
        <html>
        <head><title>Request Submitted</title></head>
        <body style="text-align: center; margin-top: 10%;">
            <h2 style="color: green;">✅ Your help request has been submitted successfully!</h2>
            
        </body>
        </html>
    '''


@app.route('/submit_help_shelter', methods=['POST'])
def submit_help_shelter():
    try:
        conn = get_db_connection()
        cur = conn.cursor()

        lat = request.form['latitude']
        lon = request.form['longitude']
        contact = request.form.get('contact', '')
        notes = request.form.get('notes', '')
        needs = request.form.getlist('needs')
        needs_str = ', '.join(needs)

        cur.execute("""
            INSERT INTO shelter_requests (latitude, longitude, needs, contact, notes)
            VALUES (%s, %s, %s, %s, %s)
        """, (lat, lon, needs_str, contact, notes))

        conn.commit()
        cur.close()
        conn.close()
        return render_template("success.html", category="Shelter")
    except Exception as e:
        return f"Error occurred: {e}"


@app.route('/submit_help_army', methods=['POST'])
def submit_help_army():
    try:
        latitude = request.form.get('latitude')
        longitude = request.form.get('longitude')
        selected_needs = request.form.getlist('needs')
        contact = request.form.get('contact')
        notes = request.form.get('notes')
        needs_text = ', '.join(selected_needs)

        db = get_db_connection()
        cursor = db.cursor()

        insert_query = """
            INSERT INTO army_requests (latitude, longitude, needs, contact, notes)
            VALUES (%s, %s, %s, %s, %s)
        """
        cursor.execute(insert_query, (latitude, longitude, needs_text, contact, notes))
        db.commit()
        cursor.close()
        db.close()

        return render_template('success.html', category='Army')
    except Exception as e:
        return f"Error occurred: {str(e)}"


@app.route('/submit_help_funds', methods=['POST'])
def submit_help_funds():
    try:
        latitude = request.form.get('latitude')
        longitude = request.form.get('longitude')
        selected_funds = request.form.getlist('funds[]')
        contact = request.form.get('contact')
        notes = request.form.get('notes')
        funds_text = ', '.join(selected_funds)

        db = get_db_connection()
        cursor = db.cursor()

        insert_query = """
            INSERT INTO funds_requests (latitude, longitude, assistance, contact, notes)
            VALUES (%s, %s, %s, %s, %s)
        """
        cursor.execute(insert_query, (latitude, longitude, funds_text, contact, notes))
        db.commit()
        cursor.close()
        db.close()

        return render_template('success.html', category='Funds')
    except Exception as e:
        return f"Error occurred: {str(e)}"





# ------------------- Run Server -------------------

if __name__ == '__main__':
    app.run(debug=True)
