const CACHE_NAME = 'disaster-aid-cache-v1';
const urlsToCache = [
  '/',
  '/help',
  '/static/styles.css',
  '/help_food.html',
  '/help_medical.html',
  '/help_shelter.html',
  '/help_army.html',
  '/help_funds.html'
];

self.addEventListener('install', function (event) {
  event.waitUntil(
    caches.open(CACHE_NAME).then(function (cache) {
      return cache.addAll(urlsToCache);
    })
  );
});

self.addEventListener('fetch', function (event) {
  event.respondWith(
    caches.match(event.request).then(function (response) {
      return response || fetch(event.request);
    })
  );
});
