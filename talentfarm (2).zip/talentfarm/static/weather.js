window.onload = function () {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showWeather, showError);
  } else {
    document.getElementById("weatherDisplay").innerHTML = "Geolocation not supported.";
  }
};

function showWeather(position) {
  const lat = position.coords.latitude;
  const lon = position.coords.longitude;
  const weatherApiKey = "a05d6653d79ebd45f5a111209c92aa11";   // openweather API
  const googleApiKey = "AIzaSyDsON8gdVVEdAOqhfp-TlEQOAH2UzZP7J4";   //google map API

  const weatherUrl = `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${weatherApiKey}&units=metric`;
  const geoUrl = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lon}&key=${googleApiKey}`;

  // Get human-readable location
  fetch(geoUrl)
    .then(res => res.json())
    .then(geo => {
      if (geo.results.length > 0) {
        const fullAddress = geo.results[0].formatted_address;
        const locationHTML = `<p><strong>Your Location:</strong> ${fullAddress}</p>`;
        document.getElementById("weatherDisplay").innerHTML = locationHTML;
      }
    })
    .catch(err => {
      console.error("Geocoding error:", err);
    });

  // Fetch 5-day forecast
  fetch(weatherUrl)
    .then(response => response.json())
    .then(data => {
      let html = `
        <h2>Weather for ${data.city.name}</h2>
        <h3>5-Day Forecast</h3>
      `;
      const forecast = data.list;

      for (let i = 0; i < forecast.length; i++) {
        const day = forecast[i];
        if (!day.dt_txt.includes("12:00:00")) continue;

        html += `
          <div class="forecast-card">
            <h4>${new Date(day.dt_txt).toDateString()}</h4>
            <p>Temp: ${day.main.temp} °C</p>
            <p>Weather: ${day.weather[0].description}</p>
            <p>Wind: ${day.wind.speed} m/s</p>
            <img src="http://openweathermap.org/img/wn/${day.weather[0].icon}@2x.png" alt="Weather Icon">
        `;

        if (day.weather[0].main.toLowerCase().includes("rain")) {
          html += "<p style='color: #ff6961;'>⚠️ Carry an umbrella!</p>";
        } else if (day.weather[0].main.toLowerCase().includes("clear")) {
          html += "<p style='color: #90ee90;'>☀️ Great weather today!</p>";
        }

        html += "</div>";
      }

      document.getElementById("weatherDisplay").innerHTML += html;
    })
    .catch(error => {
      console.error("Weather API error:", error);
      document.getElementById("weatherDisplay").innerHTML = "Error fetching weather data.";
    });
}

function showError(error) {
  let message = "";
  switch (error.code) {
    case error.PERMISSION_DENIED:
      message = "Location access denied by user.";
      break;
    case error.POSITION_UNAVAILABLE:
      message = "Location information unavailable.";
      break;
    case error.TIMEOUT:
      message = "Location request timed out.";
      break;
    default:
      message = "An unknown error occurred.";
      break;
  }
  document.getElementById("weatherDisplay").innerHTML = message;
}
